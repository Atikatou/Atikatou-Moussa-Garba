//Mahaman Adamou Aichatou

#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int a=500;
    int b=250;
    int c=200;
    int d=100;
    int e=50;
    int f=25;
    int g=10;
    int h=5;
    int i=1;
     int money;
     money=get_int("money: ");
     int j=0;

      while(money>=a)
    {
    money=money-a;
    j++;
    }
      while(money>=b)
    {
     money=money-b;
     j++;
    }
      while(money>=c)
    {
    money=money-c;
    j++;
    }
      while(money>=d)
    {
    money=money-d;
    j++;
    }
      while(money>=e)
    {
    money=money-e;
    j++;
    }
      while(money>=f)
    {
    money=money-f;
     j++;
    }
    while(money>=g)
    {
        money=money-g;
        j++;
    }
    while(money>=h)
    {
        money=money-h;
         j++;
    }
    while(money>=i)
    {
        money=money-h;
        j++;
    }
    printf("%i\n",j);
}