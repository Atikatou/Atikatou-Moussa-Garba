#include <stdio.h>
#include <cs50.h>
#include <ctype.h>
int main (void)
{

    char l= get_char("Type the character :") ;

   if (isalpha(l))
{
  printf("the character is an Alphabet\n");
 }

 else

 {
 printf("the character is not an Alphabet\n");

 }
}


