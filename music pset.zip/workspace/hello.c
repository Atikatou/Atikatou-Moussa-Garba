#include<stdio.h>
#include<cs50.h>

   int main(void)
{

 int a=get_int("a:");
 int b=get_int("b:");

    if (a%2==0)

 {
    printf("a is  even");
 }

  else

   if(b%2==0)
  {
      printf("b is even");
  }
 }