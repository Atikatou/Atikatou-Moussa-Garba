#include  <stdio.h>
#include <cs50.h>

int main (void)

{
    int number = get_int("natural numberd");
    {
        for(int i=0; i<10; i++)
    }
    printf("%i, numbers\n");
}