#include<stdio.h>
#include<ctype.h>

int main(void)
{
    int var1= 'A';
    if(islower(var1))
 {
     printf("var1=%c is an lowercase letter", var1);

 }
    else

{
    printf("is not lowercase");
}
}