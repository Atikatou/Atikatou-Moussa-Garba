//Mahaman Adamou Aichatou

#define _XOPEN_SOURCE
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <cs50.h>


int main (int argc , string argv[])
{
    if(argc != 2)
    {
        printf("usage: crack <hash>\n");
        return 1;
    }
     //get the letters
    const int harafin_count = 53;

    string harafin = "\0 abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    string hash = argv[1];

    char gichiri[3];
    memcpy (gichiri, hash, 2);
    gichiri[2] = '\0';

    char key_password[6]= "\0\0\0\0\0\0";

    for(int biyarr = 0; biyarr < harafin_count; biyarr++)
    {
     for(int houdou = 0; houdou < harafin_count; houdou++)
     {
         for(int ouckou = 0; ouckou< harafin_count; ouckou++)
         {
             for(int biyou = 0; biyou < harafin_count; biyou++)
             {
                 for(int daya = 1; daya < harafin_count; daya++)

                {
                    // enter all the password
                    key_password[0] = harafin [daya]; // 1)
                    key_password[1] = harafin [biyou];// 2)
                    key_password[2] = harafin [ouckou];// 3)
                    key_password[3] = harafin [houdou];// 4)
                    key_password[4] = harafin [biyarr];// 5)


                if(strcmp(crypt(key_password,gichiri), hash )==0)

                 {
                 printf("%s\n", key_password);
                 return 0;
                 }
             }
             }
         }
     }

    }

      printf("password couldn't be cracked !");

      return 2;

}
