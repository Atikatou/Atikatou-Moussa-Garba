#include<stdio.h>
#include <cs50.h>

int main(void)
{
    int number= get_int("number:");
    for(int i =1; i< number; i++)
    {
        printf("the number is %i\n", i);
    }
}
