typedef  struct
{

    int id;
    string name;
    char sex;
    int quize1;
    int quize2;
    int midscore;
    int finalscore;
    int totalscore;
}
  student;
