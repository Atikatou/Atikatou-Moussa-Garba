#include <stdio.h>
#include <cs50.h>

int main(void){

    int nombre;
do{
    nombre= get_int("donner un nombre positif");
}
 while(nombre<=0);
for(int i=0; i<nombre ; i++){
    for(int espace=nombre-i; espace>1; espace--)
    {
        printf(" ");
    }

    for(int col=0 ; col<=i; col++)
    {

      printf("#");
    }
    printf(" ");
    for(int col1=0; col1<=i; col1++)
    {
        printf("#");
    }
 printf("\n");
   }


while(nombre<=0);
for(int i=0; i<nombre ; i++){
    for(int espace=nombre-i; espace>1; espace--)
    {
        printf(" ");
    }

    for(int col=0 ; col<=i; col++)
    {

      printf("#");
    }
    printf(" ");
    for(int col1=0; col1<=i; col1++)
    {
        printf("#");
    }
 printf("\n");
   }

}