#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main(int argc, string argv[]);

{
    if (argc != 2)
    {
        printf("usage: ./caesar k\n");
        return 1
    }

    {
        int k = atoi(argv[1])
                if (k < 0)

        {
            printf("the key must be positive\n");
            return 1;
        }
        string k = argv[1];
        string plaintext = get_string("plaintext: ");

    }
     //print the cyphertext
         {
            printf("cyphertext: ");
         }

}