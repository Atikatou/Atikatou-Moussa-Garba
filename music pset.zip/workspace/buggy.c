#include <cs50.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main(void)
{
    // print a name 20 times

 string name= get_string("Name:");
    for ( i = 0; i < 20; i++)
    {
    int i= 0;
    n = char ((name[0]));
    if ( islower, name[0])
    {
        printf("%c,toupper(name[0])");
    }
     else
     {
         printf("%c, name[0]");
     }
     for (i = 0; i < n; i++)
     {
         printf("%c, (name[i+1])");
     }
    }
}