#include <stdio.h>
#include <cs50.h>

int main (void)
{
    int size= get_int("size:");
    int array[size];

    for(int i = 0; i < size ; i ++)
    {

        array[i] = get_int("number:");
    }
    for( int j = 0; j < size; j++)
    {
        printf("the size is %i\n", array[j]);
    }

}