#include <stdio.h>
#include <cs50.h>

int main (void)
{
     //GETTING
     int a=get_int ("number one");
     int b=get_int ("number two");
     int c=get_int ("number three");


   if (a<b && b<c)
 {
    printf("%i <%i <%i",a,b,c);
 }
   if (b<a && a<c)
 {
  printf("%i <%i <%i",b,a,c);
 }
   if (a<c && c<b)
 {
    printf("%i <%i <%i",a,c,b);
 }
   if (b<c && c<a)
 {
    printf("%i <%i <%i",b,c,a);
 }
   if (c<a && a<b)
 {
    printf("%i <%i <%i",c,a,b);
 }
   if (c<b && b<a)
 {
   printf("%i <%i <%i",c,b,a);
 }

}