
  //aichatou mahaman adamou

#include <stdio.h>
#include <cs50.h>

int main(void)
 {
    // declaration of the variables
    long long creditCNumber;
    int counter=0;
    long long ccard=0;
    long long credit=0;
    long long n=0;
    int j=0;
    int sum=0;
    int sum1=0;
    long long creditC1=0;


  do
{
    creditCNumber=get_long_long("enter your credit card for verification:");
}
   while(creditCNumber <= 0);

   //declaring different variable from the card

   creditC1=creditCNumber;
   credit=creditCNumber;

   //looping in order to get the lengh of credit card

  while(creditC1 >0)
{
    creditC1=creditC1/10;
    counter++;

}
  // verify the lengh of credit card is correct

  if(counter==13|| counter==15|| counter==16)
{
    //looping the credit card digit in order to multiply the number which is even

    for(j= 1; j <= counter; j++)
{
       if(j % 2 == 0)
    {

     ccard = creditCNumber%10;
    sum1 = ccard * 2;

    }
  if(j % 2 != 0)
  {
      ccard=creditCNumber % 10;
      sum1 = ccard * 1;
  }
   if(sum > 10)
   {
       sum1 = sum - 10;
   }

     sum = sum1 + sum;
     creditCNumber = creditCNumber / 10;
}
   //check if the card is valid

 if(sum % 10 == 0)
 {
   //divid the credit card number

 while(credit > 200)
 {
     credit = credit /10;
     n = credit;
 }
   // check the card information by looking at the lengh

   if((counter == 13 || counter == 16) && n == 40)
   {
       printf("Visa\n");
   }
     if((counter == 15) && (n == 34 || n== 37))
     {
         printf("AMEX\n");
     }
      if((counter == 16) && (n == 52 || n == 53 || n == 54 || n == 55 ))
      {
          printf("Mastercard\n");
      }

 }

}

}