#include <stdio.h>
#include <cs50.h>
int main(void)

{
    long_long a= get long_long ("type variable a");
    int additionum, x2prod, sum;

    //num de la carte
    printf("number of the carte\n");
    get_long_long;
}
    if (i<0);

  //additionne les chiffres

  for(xadd=i, additionum = 0; xadd>0; xadd/=100)
  addums+xadd%10;

  //double les chiffres en partant du deuxiemme au dernier

 for(x2=i/10, x2prod=0, x2>0; x2/=100)
 {
     if(2*(x2%10)>9)
    {
        x2prod+=(2*(x2%10))/10;
        x2prod+=(2*(x2%10))%10;
    }
 }
