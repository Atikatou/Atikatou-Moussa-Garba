typedef  struct
{

    float id;
    string name;
    string sex;
    float 2quizes;
    float midterm score;
    float final score;
    float total score;
}
   student;
