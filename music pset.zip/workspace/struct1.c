#include<cs50.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#include "struct.h"

int main(void)

{
    //allocate research for each 20 students

     student students[20];

     //prompt for students' ID,name, sex, quizes,midscore,finalscore, totalscore

     for(int i=0; i<20; i++)
  {
         students[i].id=get_int("id:");
         students[i].name=get_string("name:");
         students[i].sex=get_char("sex:");
         students[i].quize1=get_int("quize1:");
         students[i].quize2=get_int("quize2:");
         students[i].midscore=get_int("midscore:");
         students[i].finalscore=get_int("finalscore:");
         students[i].totalscore=get_int("totalscore:");


     {
         printf("%d,%s,%c,%d,%d,%d,%d,%d\n",students[i].id, students[i].name, students[i].sex, students[i].quize1, students[i].quize2,students[i].midscore, students[i].finalscore, students[i].totalscore);
     }
  }

}
