#include <stdio.h>
#include <cs50.h>

int main (void)
{
    int myage= get_int("20");
    printf("my age is  %i:, 20");
}