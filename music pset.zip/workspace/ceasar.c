//WOLO BORIS KEVIN

#include <stdio.h>
#include <stdlib.h>
#include <cs50.h>
#include <ctype.h>
#include <string.h>
int main(int argc, string argv[])

{
    if (argc != 2)


    int k = atoi (argv[1]);

    string p = get_string("plaintext: ");


    for (int i = 0, n = strlen(p) ; i < n; i++)

{
    printf("the cyphertext:");
}
        {

            printf("%c", (((p[i] - 'a') + k) % 26) + 'a');
            // print out lowercase with key

        } // if it it between uppercase A and C

        else if (p[i] >= 'A' && p[i] <= 'Z')

        {

            printf("%c", (((p[i] - 'A') + k) % 26) + 'A');
            // print out uppercase with key

        }

        else
    {
            printf("%c", p[i]);

   }

{
        printf("is alphabet: \n");

        return 1;
    }

    }



