#include<stdio.h>
#include<cs50.h>
int main(void);
{
int a=2;
int b=10;
if(a>b)
{
    printf("a is less than b");
}

}