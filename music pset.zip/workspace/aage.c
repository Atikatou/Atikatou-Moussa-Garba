#include <stdio.h>
#include <cs50.h>

int main(void)
{
   int age = get_int("age:");

    if(age %2==0)
    {
        printf("age is even");
    }
   else
   {
       printf("age is odd");
   }

}