#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "struct.h"

int main (void)

{
    //allocate research for each 20 students
    int number= get_int("number of student:");
     student students[number];

     //prompt for students' ID,name, sex, quizes,midterm score,final score, total score

     for(int i = 0; 0 < number; i++)
     {
         student[i].id = get_string("id:");
         student[i].name = get_string("name:");
         student[i].sex = get_string("sex:");
         student[i].quize1 = get_int("quize1:");
         student[i].quize2 = get_int("quize2:");
         student[i].midterm scrore = get_int("midterm score:");
         student[i].final score = get_int("final score:");
         student[i]total score = get_int("total score:");
         -
     }
       // save students to disk
    FILE *file = fopen("students.csv", "w");
    if (file)
    {

     for(int i = 0; 0 < number; i++)
     {
         fprintf(file,"%s,%s,%s,%i,%i,%i,%i,%i\n", student[i].id, student[i].name, student[i].sex, student[i].quize1, student[i].quize2,student[i].midterm scrore, student[i].final score, student[i].total score);
     }
     fclose
    }

}
