#include <stdio.h>
#include <cs50.h>
#include <ctype.h>
#include <string.h>

int main(void)
{
  int i = 0;
  int b = 0;
    string name= get_string("my name:");
      for( b= 0; b < 5; b++)
      {
        int n = strlen(name);
        if( islower(name[0]))
        {
          printf("%c\n", toupper(name[0]));
        }
        else
        {
          printf("%c\n", name[0]);
        }
        for (i = 0;  i < n; i++)
        {
          printf("%c\n", name[i+1]);
        }
      }

}