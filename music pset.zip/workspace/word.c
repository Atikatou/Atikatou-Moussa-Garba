#include <stdio.h>
int main (void)

{
    printf("hello world");

   /*this is a comment

   printf("hello Again");

   this is another comment*/
}
