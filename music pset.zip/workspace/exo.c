#include <stdio.h>
#include <cs50.h>

int main(void)
{
    //GETTING
    int d = get_int("type d:");
    int e= get_int("type e:");
    int f= get_int("type f:");


 if (d<e && e<f)
 {
     printf("%i <%i <%i",d,e,f);
 }
       if(d<f && f<e)
 {
   printf("%i <%i <%i",d,f,e);
 }
    if(e<d && d<f)
 {
    printf("%i <%i <%i",e,d,f);
 }
    if(e<f && f<d)
 {
   printf("%i <%i <%i",e,f,d);
 }
    if(f<d && d<e)
 {
    printf("%i <%i <%i",f,d,e);
 }
    if(f<e && e<d)
 {
    printf("%i <%i <%i",f,e,d);
 }

}





