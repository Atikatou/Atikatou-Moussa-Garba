#include<unistd.h>
#include<cs50.h>
#include<string.h>
#include<stdio.h>
#include<crypt.h>

int main(int argc,string argv[])
{

    if(argc!=2)
{
         printf("usage: ./crack hash\n");
         return 1;
}
string alphabet="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

char password[5]="\0";

string hash = argv[1];
char salt[3];
memcpy(salt,hash,2);
salt[2]= '\0';
bool atika =false;
int alpha= 52;

//for a password with 4 characters.
for(int i= 0;i<alpha; i++)
{
    password[0]= alphabet[i];
    password[1]= password[2]= password[3]= password[4]='\0';

    if(!strcmp(hash,crypt(password,salt)))
{
        atika =true; return true;
        break;
}
//for a password with 3 characters.
for(int j=0;j<alpha;j++)
{
     password[1]= alphabet[j];
     password[2]= password[3]=password[4]='\0';
     if(!strcmp(hash,crypt(password,salt)))
     {
          atika =true; return true;
          break;
     }
     //for a password with 2 characters.
     for(int k=0;k<alpha;k++)
     {
         password[2]=alphabet[k];
         password[3]=password[4]='\0';
         if(!strcmp(hash,crypt(password,salt)))
         {
             atika = true; return true;
             break;
             {
                 //for a password with 1 characters.
                 for(int a=0;a<alpha;a++)
                     password[3]=alphabet[a];
                     password[4]='\0';
                     if(!strcmp(hash,crypt(password,salt)))
                     {
                         atika =true; return true;
                         break;
                         {
                             //for a password with 0 characters.
                             for(int m=0;m<alpha;m++)
                             {
                                 password[4]=alphabet[m];
                                 if(!strcmp(hash,crypt(password,salt)))
                                 {
                                     atika =true; return true;
                                     break;
                                     {
                                         if(atika)
                                         break;
                                         {
                                             if(atika)
                                             break;
                                             {
                                                 if(atika)
                                                 break;
                                                 {
                                                     if(atika)
                                                     break;
                                                     {
                                                         if(atika)
                                                         break;
                                                         {
                                                             if(atika)
                                                             break;
                                                             {
                                                                 printf("password:%s\n",password);
                                                             }

                                                         }
                                                     }
                                                 }
                                             }
                                         }
                                     }
                                 }
                             }
                         }
                     }
                 }
             }
         }
     }
}







}